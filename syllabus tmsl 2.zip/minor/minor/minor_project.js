let currentSlide = 0;
let container = null;
let slides = null;
let totalSlides = 0;

// Function to initialize slider elements
function initializeSlider() {
    container = document.querySelector('.container');
    slides = document.querySelectorAll('.page');
    totalSlides = slides.length;
}

// Function to show a specific slide
function showSlide(index) {
    if (!container || totalSlides === 0) return;
    const translateValue = -index * 100;
    container.style.transform = `translateX(${translateValue}vw)`;
}

// Function to move to the next slide
function nextSlide() {
    if (!container || totalSlides === 0) return;
    currentSlide = (currentSlide + 1) % totalSlides;
    showSlide(currentSlide);
}

// Auto-slide every 5 seconds
function startSlider() {
    if (container && totalSlides > 0) {
        showSlide(currentSlide); // Show first slide immediately
        setInterval(nextSlide, 5000);
    } else {
        console.error('Slider failed to start: Container or slides not found.');
    }
}

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (window.scrollY > 100) {
        header.style.top = '-100px';
    } else {
        header.style.top = '0';
    }
});

// News Board Functionality
const newsItems = [
    { text: "College event on campus!", isNew: true, label: "NEW" },
    { text: "New courses available", isNew: true, label: "UPDATE" },
    { text: "Upcoming placement interviews", isNew: false }
];

function updateNewsBoard() {
    const newsList = document.getElementById('news-list');
    if (newsList) {
        newsList.innerHTML = '';

        newsItems.forEach(item => {
            const newsItem = document.createElement('div');
            newsItem.className = 'news-item';
            if (item.isNew) {
                newsItem.classList.add('new');
                newsItem.innerHTML = `<p><span class="new-label">${item.label}:</span> ${item.text}</p>`;
            } else {
                newsItem.innerHTML = `<p>${item.text}</p>`;
            }
            newsList.appendChild(newsItem);
        });
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateNewsBoard();
    initializeSlider();
    startSlider();
});